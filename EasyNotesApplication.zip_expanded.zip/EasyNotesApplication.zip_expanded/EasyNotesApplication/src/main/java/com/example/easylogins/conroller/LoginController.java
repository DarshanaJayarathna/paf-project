package com.example.easylogins.conroller;

import com.example.easylogins.exception.ResourceLoginFoundException;
import com.example.easylogins.model.Login;
import com.example.easylogins.repository.LoginRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api")
public class LoginController {
    @Autowired
    LoginRepository LoginRepository;

    // Get All Login
    @GetMapping("/logins")
    public List<Login> getAllLogins() {
        return LoginRepository.findAll();
    }
    // Create a new Login
    @PostMapping("/logins")
    public Login createLogin(@Valid @RequestBody Login login) {
        return LoginRepository.save(login);
    }
    // Get a Single Login
    @GetMapping("/logins/{id}")
    public Login getLoginById(@PathVariable(value = "id") Long loginId) {
        return LoginRepository.findById(loginId)
                .orElseThrow(() -> new ResourceLoginFoundException("Login", "id", loginId));
    }
    // Update a Login
    @PutMapping("/logins/{id}")
    public Login updateLogin(@PathVariable(value = "id") Long loginId,
                                            @Valid @RequestBody Login loginDetails) {

        Login login = LoginRepository.findById(loginId)
                .orElseThrow(() -> new ResourceLoginFoundException("Login", "id", loginId));

        login.setName(loginDetails.getName());
        login.setEmail(loginDetails.getEmail());
        login.setPassword(loginDetails.getPassword());

        Login updatedLogin = LoginRepository.save(login);
        return updatedLogin;
    }
    // Delete a Login
    @DeleteMapping("/logins/{id}")
    public ResponseEntity<?> deleteNote(@PathVariable(value = "id") Long loginId) {
        Login login = LoginRepository.findById(loginId)
                .orElseThrow(() -> new ResourceLoginFoundException("Login", "id", loginId));

        LoginRepository.delete(login);

        return ResponseEntity.ok().build();
    }
}
