package com.example.easypayments.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.easypayments.model.Payment;
import com.example.easypayments.repository.PaymentRepository;
import com.example.easypayments.exception.ResourcePaymentFoundException;

@RestController
@RequestMapping("/api")
public class PaymentController {
	
	@Autowired
    PaymentRepository PaymentRepository;
	
	 // Get All payment
    @GetMapping("/payments")
    public List<Payment> getAllPayments() {
        return PaymentRepository.findAll();
    }
    
 // Create a new Payment
    @PostMapping("/payments")
    public Payment createPayment(@Valid @RequestBody Payment payment) {
        return PaymentRepository.save(payment);
    }
    
    // Get a Single payment
    @GetMapping("/payments/{id}")
    public Payment getPaymentById(@PathVariable(value = "id") Long paymentId) {
        return PaymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourcePaymentFoundException("Payment", "id", paymentId));
    }
    // Update a Payment
    @PutMapping("/payments/{id}")
    public Payment updatePayment(@PathVariable(value = "id") Long paymentId,
                                            @Valid @RequestBody Payment paymentDetails) {

    	Payment Payment = PaymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourcePaymentFoundException("Payment", "id", paymentId));

    	Payment.setName(paymentDetails.getName());
    	Payment.setEmail(paymentDetails.getEmail());
    	Payment.setPassword(paymentDetails.getPassword());

    	Payment updatedPayment = PaymentRepository.save(Payment);
        return updatedPayment;
    }
    // Delete a payment
    @DeleteMapping("/payments/{id}")
    public ResponseEntity<?> deleteNote(@PathVariable(value = "id") Long paymentId) {
    	Payment payment = PaymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourcePaymentFoundException("Payment", "id", paymentId));

        PaymentRepository.delete(payment);

        return ResponseEntity.ok().build();
    }
}
