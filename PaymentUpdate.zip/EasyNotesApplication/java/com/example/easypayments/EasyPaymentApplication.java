package com.example.easypayments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.example.easypayments.EasyPaymentApplication;

@SpringBootApplication
@EnableJpaAuditing
public class EasyPaymentApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(EasyPaymentApplication.class, args);
	}

}
