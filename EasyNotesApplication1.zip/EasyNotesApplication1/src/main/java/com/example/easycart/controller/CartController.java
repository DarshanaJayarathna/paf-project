package com.example.easycart.controller;

import com.example.easycart.exception.ResourceCartFoundException;
import com.example.easycart.model.Cart;
import com.example.easycart.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api")
public class CartController {

    @Autowired
    CartRepository cartRepository;

    // Get All Carts
    @GetMapping("/cart")
    public List<Cart> getAllCart() {
        return cartRepository.findAll();
    }
    // Create a new Cart
    @PostMapping("/cart")
    public Cart createCart(@Valid @RequestBody Cart cart) {
        return cartRepository.save(cart);
    }
    // Get a Single Cart
    @GetMapping("/cart/{id}")
    public Cart getCartById(@PathVariable(value = "id") Long cartId) {
        return cartRepository.findById(cartId)
                .orElseThrow(() -> new ResourceCartFoundException("Cart", "id", cartId));
    }
    // Update a Cart
    @PutMapping("/cart/{id}")
    public Cart updateCart(@PathVariable(value = "id") Long cartId,
                                            @Valid @RequestBody Cart cartDetails) {

        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new ResourceCartFoundException("Cart", "id", cartId));

        cart.setItem(cartDetails.getItem());
        cart.setPrice(cartDetails.getPrice());
        cart.setQuantity(cartDetails.getQuantity());
        cart.setTotal(cartDetails.getTotal());
        
        
        Cart updatedCart = cartRepository.save(cart);
        return updatedCart;
    }
    // Delete a Cart
    @DeleteMapping("/cart/{id}")
    public ResponseEntity<?> deleteCart(@PathVariable(value = "id") Long cartId) {
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new ResourceCartFoundException("Cart", "id", cartId));

        cartRepository.delete(cart);

        return ResponseEntity.ok().build();
    }
}