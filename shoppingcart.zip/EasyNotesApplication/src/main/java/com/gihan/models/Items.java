package com.gihan.models;

import java.sql.Connection; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.sql.Statement;

public class Items 
{

	public String getItems() 
	{             
		String itemsGrid = null;             
		Connection con = null;             
		Statement st = null;             
		ResultSet rs = null;       
		
		try {       
			con = DBConnection.createConnection();     
			st = con.createStatement();    
			rs = st.executeQuery("select * from items");     
			
			if (rs.first())       
			{ 
				itemsGrid = "<table border='1' cellspacing='1' cellpadding='1'>"
						+ "<tr>"
						+ "<th>No</th>"
						+ "<th>Item</th>"
						+ "<th>price</th>"
						+ "<th>quantity</th>"
						+ "<th>total</th>"
						+ "<th>Add</th>"
						+ "<th>Delete</th>"
						+ "</tr>"; 
				rs.beforeFirst(); 
				
				while(rs.next())  
				{   
					itemsGrid = itemsGrid + "<tr><td>" + rs.getString(1) + 
							"</td>"      + "<td>" + rs.getString(2) + "</td>"     
							+ "<td>" + rs.getString(3) + "</td>"      
							+ "<td><input id=\"btnSave\" type=\"button\" name=\"btnSave\"  param=\"" 
							+ rs.getString(1) + "\" value=\"Edit\"</td>"      
							+ "<td>" + "<input id=\"btnRemove\" type=\"button\" name=\"btnRemove\" param=\"" 
							+ rs.getString(1) + "\" value=\"Remove\"</td></tr>";                        
				} 
				
			}                   
			else                         
				itemsGrid = "There are no items...";                   
				itemsGrid = itemsGrid + "</table></br>";             
			}             
		catch (SQLException e) 
		{                   
			e.printStackTrace();             
		}             
		
		return itemsGrid;       
		
		}       
	
		public String saveAnItem(String Item, String price,String quantity,String total) 
		{
			String res = null;             
			String sql = null;            
			Connection con = null;             
			Statement st = null;             
			try 
			{                   
				con = DBConnection.createConnection();                  
				st = con.createStatement();                  
				sql = "insert into cart (Item, price,quantity,total) values ('" + Item + "', '" + price + "','" + quantity + "','" + total + "')";                   
				st.executeUpdate(sql);                   
				res = "Successfully inserted...";             
			}             
			catch (SQLException e) 
			{                   
				e.printStackTrace();             
			}             
			
			return res;       
			
		}
			}
		