function nicValidation(nic,nic) {      
	var regExpression = /^[0-9]{9}[vVxX]$/;      
	if (!regExpression.test(nic)) {          
		id.style.backgroundColor = "red";          
		alert("Invalid NIC")      }
	else{          
	value.style.backgroundColor = "";      
		}  
}